# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'phones',
    'version': '1.0',
    'summary': 'phones models',
    'website':'www.phonestoview.com',
    'description': """
                            Something that is not importent
    """,
    'depends': ['base'],
    'data': [
        'views/main_view.xml',
    ],
    'sequence': '0',
    'installable': True,
    'application': True,
    'auto_install': False,
}
