{
    'name': 'libretafacturas',
    'description': 'Modulo para gestionar una lista de facturas',
    'author': 'Fco Javier Sabio Viñolo',
    'application': True,
    'data': ['views/producto.xml', 'views/facturas.xml', 'views/cliente.xml']
}